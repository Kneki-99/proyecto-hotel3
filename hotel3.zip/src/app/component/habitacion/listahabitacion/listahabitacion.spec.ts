import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Listahabitacion } from './listahabitacion';

describe('Listahabitacion', () => {
  let component: Listahabitacion;
  let fixture: ComponentFixture<Listahabitacion>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Listahabitacion]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Listahabitacion);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
