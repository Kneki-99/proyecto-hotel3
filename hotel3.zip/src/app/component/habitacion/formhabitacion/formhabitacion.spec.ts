import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Formhabitacion } from './formhabitacion';

describe('Formhabitacion', () => {
  let component: Formhabitacion;
  let fixture: ComponentFixture<Formhabitacion>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Formhabitacion]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Formhabitacion);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
