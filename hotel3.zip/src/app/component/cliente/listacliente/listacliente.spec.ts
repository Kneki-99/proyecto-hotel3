import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Listacliente } from './listacliente';

describe('Listacliente', () => {
  let component: Listacliente;
  let fixture: ComponentFixture<Listacliente>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Listacliente]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Listacliente);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
