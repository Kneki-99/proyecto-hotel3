import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Formcliente } from './formcliente';

describe('Formcliente', () => {
  let component: Formcliente;
  let fixture: ComponentFixture<Formcliente>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Formcliente]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Formcliente);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
